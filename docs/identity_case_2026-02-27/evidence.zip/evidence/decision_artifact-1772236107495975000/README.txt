Aman Evidence Bundle

Files:
- decision.json: Decision summary, hashes, and audit chain pointers.
- why_chain.json: Causal reasoning chain per rule (verdicts + explanations).
- counterfactuals.json: "what-if" analysis and next likely actions.
- controls.json: Framework control mappings + policy/audit lifecycle metadata.
- oversight.json: Human approvals and dual-control status.
- summary.json: Human-friendly summary of the bundle contents.
- report.html: Human-readable view (open in a browser).
- rule_catalog_version.json: Rule catalog count and source.
- manifest.json: Bundle manifest with file hashes.

Verification:
- Use: aman audit bundle-verify --bundle <bundle.zip>
- The manifest digest + optional signature provide integrity.